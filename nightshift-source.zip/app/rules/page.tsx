import Portal from '@/components/portal';
export const metadata={title:'თამაშის წესები — NIGHTSHIFT'};
export default function Page(){return <Portal view="rules"/>;}
