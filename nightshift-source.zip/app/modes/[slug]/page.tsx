import Portal from '@/components/portal';
import {modeBySlug} from '@/lib/catalog';
import {notFound} from 'next/navigation';
export async function generateMetadata({params}:{params:Promise<{slug:string}>}){const {slug}=await params;const m=modeBySlug(slug);return {title:m?`${m.name} — NIGHTSHIFT`:'რეჟიმი ვერ მოიძებნა',description:m?.description};}
export default async function Page({params}:{params:Promise<{slug:string}>}){const {slug}=await params;if(!modeBySlug(slug))notFound();return <Portal view="mode" slug={slug}/>;}
