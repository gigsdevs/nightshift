import Portal from '@/components/portal';
export const metadata={title:'პროფილი — NIGHTSHIFT'};
export default function Page(){return <Portal view="profile"/>;}
