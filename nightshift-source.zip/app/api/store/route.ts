import { checkoutEnabled } from '@/lib/stripe';
export async function GET() {
  return Response.json({ cardEnabled: checkoutEnabled(), cryptoEnabled: false }, { headers: { 'Cache-Control': 'no-store' } });
}
