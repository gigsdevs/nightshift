import {supabasePublic,jsonError} from '@/lib/server-data';
import type {RankedPlayer} from '@/lib/catalog';
export async function GET(){try{const {data,error}=await supabasePublic().from('player_stats').select('*').order('rating',{ascending:false}).limit(500);if(error)throw error;return Response.json({players:data as RankedPlayer[],demo:false},{headers:{'Cache-Control':'no-store'}});}catch(e){console.error('Leaderboard unavailable',e);return Response.json({players:[],demo:false},{headers:{'Cache-Control':'no-store'}});}}
