import { verifyStripeSignature, membershipExpiry } from '@/lib/stripe';
import { findPlan } from '@/lib/store';
import { supabaseAdmin } from '@/lib/server-data';
export const runtime = 'nodejs';
export async function POST(request: Request) {
  const secret = process.env.STRIPE_WEBHOOK_SECRET;
  if (!secret || !process.env.SUPABASE_SERVICE_ROLE_KEY) return new Response('Webhook not configured', { status: 503 });
  const body = await request.text();
  if (body.length > 1000000) return new Response('Payload too large', { status: 413 });
  if (!verifyStripeSignature(body, request.headers.get('stripe-signature') || '', secret)) return new Response('Invalid signature', { status: 400 });
  try {
    const event = JSON.parse(body);
    if (event.livemode !== process.env.STRIPE_SECRET_KEY?.startsWith('sk_live_')) return new Response('Mode mismatch', { status: 400 });
    const session = event.data.object;
    if (event.type === 'checkout.session.completed' || event.type === 'checkout.session.async_payment_succeeded') {
      if (session.payment_status !== 'paid') return Response.json({ received: true });
      const plan = findPlan(session.metadata?.plan_id);
      const userId = session.metadata?.user_id;
      if (!plan || typeof userId !== 'string' || !/^[0-9a-f-]{36}$/i.test(userId) || session.client_reference_id !== userId || session.amount_total !== plan.cents || session.currency !== 'usd' || session.mode !== 'payment') return new Response('Invalid purchase', { status: 400 });
      const { error } = await supabaseAdmin().from('store_memberships').upsert({
        session_id: session.id, user_id: userId, plan_id: plan.id, role: 'admin', vip_tier: null,
        amount_cents: plan.cents, payment_intent: session.payment_intent,
        expires_at: membershipExpiry(event.created, plan.months),
      }, { onConflict: 'session_id', ignoreDuplicates: true });
      if (error) throw error;
    } else if (event.type === 'charge.refunded' && session.payment_intent) {
      const { error } = await supabaseAdmin().from('store_memberships').update({ revoked: true }).eq('payment_intent', session.payment_intent);
      if (error) throw error;
    }
    return Response.json({ received: true });
  } catch { return new Response('Processing failed', { status: 500 }); }
}
