import { bearer, jsonError, safeOrigin, userClient } from '@/lib/server-data';
import { findPlan } from '@/lib/store';
import { checkoutEnabled } from '@/lib/stripe';
export const runtime = 'nodejs';
export async function POST(request: Request) {
  if (!safeOrigin(request)) return jsonError('არასწორი მოთხოვნა.', 403);
  if (!checkoutEnabled()) return jsonError('ბარათით გადახდა ჯერ არ არის გააქტიურებული.', 503);
  const token = bearer(request);
  if (!token) return jsonError('საჭიროა ანგარიშში შესვლა.', 401);
  try {
    const text = await request.text();
    if (text.length > 500) return jsonError('მოთხოვნა ზედმეტად დიდია.', 413);
    const body = JSON.parse(text);
    const plan = findPlan(body.planId);
    if (!plan || Object.keys(body).some(key => key !== 'planId')) return jsonError('არასწორი პაკეტი.');
    const { data: { user }, error } = await userClient(token).auth.getUser(token);
    if (error || !user) return jsonError('საჭიროა ანგარიშში შესვლა.', 401);
    const origin = new URL(request.url).origin;
    const params = new URLSearchParams({
      mode: 'payment', 'payment_method_types[0]': 'card',
      success_url: `${origin}/shop?payment=processing`, cancel_url: `${origin}/shop?payment=cancelled`,
      client_reference_id: user.id, 'metadata[user_id]': user.id, 'metadata[plan_id]': plan.id,
      'line_items[0][quantity]': '1', 'line_items[0][price_data][currency]': 'usd',
      'line_items[0][price_data][unit_amount]': String(plan.cents),
      'line_items[0][price_data][product_data][name]': `NIGHTSHIFT Admin — ${plan.label}`,
    });
    const result = await fetch('https://api.stripe.com/v1/checkout/sessions', {
      method: 'POST', headers: { Authorization: `Bearer ${process.env.STRIPE_SECRET_KEY}`, 'Content-Type': 'application/x-www-form-urlencoded' }, body: params,
      signal: AbortSignal.timeout(15000),
    });
    if (!result.ok) return jsonError('გადახდის დაწყება ვერ მოხერხდა. სცადე მოგვიანებით.', 502);
    const session = await result.json();
    if (typeof session.url !== 'string' || new URL(session.url).hostname !== 'checkout.stripe.com') throw new Error('Invalid checkout URL');
    return Response.json({ url: session.url }, { headers: { 'Cache-Control': 'no-store' } });
  } catch (error) {
    return jsonError(error instanceof SyntaxError ? 'არასწორი მონაცემები.' : 'გადახდის დაწყება ვერ მოხერხდა.', error instanceof SyntaxError ? 400 : 503);
  }
}
