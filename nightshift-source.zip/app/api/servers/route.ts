import {getServers,jsonError} from '@/lib/server-data';
export async function GET(){try{return Response.json(await getServers(),{headers:{'Cache-Control':'no-store'}});}catch(e){console.error('Server list unavailable',e);return jsonError('სერვერების სია დროებით მიუწვდომელია.',503);}}
