import Portal from '@/components/portal';
export const metadata={title:'ფავორიტები — NIGHTSHIFT'};
export default function Page(){return <Portal view="favorites"/>;}
