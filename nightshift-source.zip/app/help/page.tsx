import Portal from '@/components/portal';
export const metadata={title:'დახმარება — NIGHTSHIFT'};
export default function Page(){return <Portal view="help"/>;}
