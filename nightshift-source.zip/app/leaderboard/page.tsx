import Portal from '@/components/portal';
export const metadata={title:'რეიტინგი — NIGHTSHIFT'};
export default function Page(){return <Portal view="leaderboard"/>;}
