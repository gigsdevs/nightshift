import Portal from '@/components/portal';
import {modeBySlug} from '@/lib/catalog';
export const metadata={title:'სერვერები — NIGHTSHIFT'};
export default async function Page({searchParams}:{searchParams:Promise<{mode?:string}>}){const p=await searchParams;return <Portal view="servers" initialMode={p.mode&&modeBySlug(p.mode)?p.mode:'all'}/>;}
