import Portal from '@/components/portal';
export const metadata={title:'Admin — NIGHTSHIFT'};
export default function Page(){return <Portal view="admin"/>;}
