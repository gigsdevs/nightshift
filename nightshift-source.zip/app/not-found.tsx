import Link from 'next/link';
export default function NotFound(){return <main className="not-found"><span className="eyebrow">NIGHTSHIFT</span><h1>404</h1><h2>ეს გვერდი ვერ მოიძებნა</h2><p>დაუბრუნდი რეჟიმებს და იპოვე შენი შემდეგი თამაში.</p><Link className="btn primary" href="/">მთავარ გვერდზე დაბრუნება</Link></main>;}
