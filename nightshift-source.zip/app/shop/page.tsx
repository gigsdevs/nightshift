import Portal from '@/components/portal';
export const metadata = { title: 'მაღაზია — NIGHTSHIFT', description: 'VIP Basic, VIP Major, VIP Grand, VIP ELITE და Admin — NIGHTSHIFT მაღაზია.' };
export default function Page() { return <Portal view="shop" />; }
