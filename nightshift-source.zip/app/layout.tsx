import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = { title: "NIGHTSHIFT — CS2 Community", description: "შენი თამაში. შენი წესები. CS2 სერვერები, 18 თამაშის რეჟიმი, რეიტინგი და შენი მოთამაშის პროფილი.", icons: { icon:"/favicon.svg", shortcut:"/favicon.svg" } };
export default function RootLayout({children}:{children:React.ReactNode}) { return <html lang="ka"><body>{children}</body></html>; }
