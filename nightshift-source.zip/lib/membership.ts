export const vipTiers = ['basic', 'major', 'grand', 'elite'] as const;
export type VipTier = typeof vipTiers[number];
export type Membership = { role: 'player' | 'vip' | 'admin'; vipTier: VipTier | null; expiresAt: string | null };
export const vipNames: Record<VipTier, string> = { basic: 'VIP Basic', major: 'VIP Major', grand: 'VIP Grand', elite: 'VIP ELITE' };

// Only consume app_metadata returned by a verified getUser call. Never user_metadata.
export function resolveMembership(metadata: Record<string, unknown>, email?: string, adminEmails = '', now = Date.now()): Membership {
  const allow = adminEmails.split(',').map(value => value.trim().toLowerCase()).filter(Boolean);
  const siteAdmin = !!email && allow.includes(email.toLowerCase());
  const tier = vipTiers.includes(metadata.vip_tier as VipTier) ? metadata.vip_tier as VipTier : null;
  const expiry = typeof metadata.membership_expires_at === 'string' ? metadata.membership_expires_at : null;
  const active = !expiry || (Number.isFinite(Date.parse(expiry)) && Date.parse(expiry) > now);
  const role = siteAdmin || (metadata.role === 'admin' && active) ? 'admin' : (tier || metadata.role === 'vip') && active ? 'vip' : 'player';
  return { role, vipTier: active ? tier : null, expiresAt: active ? expiry : null };
}

export function mergeMemberships(base: Membership, purchases: {role:string;vip_tier:string|null;expires_at:string|null;revoked:boolean}[], now = Date.now()): Membership {
  const candidates: Membership[] = [base];
  for (const row of purchases) {
    if (row.revoked || (row.expires_at && !(Date.parse(row.expires_at) > now))) continue;
    if (row.role === 'admin') candidates.push({role:'admin',vipTier:null,expiresAt:row.expires_at});
    else if (row.role === 'vip' && vipTiers.includes(row.vip_tier as VipTier)) candidates.push({role:'vip',vipTier:row.vip_tier as VipTier,expiresAt:row.expires_at});
  }
  const rank = (m: Membership) => m.role === 'admin' ? 100 : m.role === 'vip' ? vipTiers.indexOf(m.vipTier!) + 1 : 0;
  candidates.sort((a,b) => rank(b)-rank(a) || (b.expiresAt?Date.parse(b.expiresAt):Infinity)-(a.expiresAt?Date.parse(a.expiresAt):Infinity));
  return candidates[0];
}
