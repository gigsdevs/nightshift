import {z} from 'zod';
import {createClient} from '@supabase/supabase-js';
import {modeBySlug, type GameServer} from './catalog';

const serverSchema=z.object({id:z.string().regex(/^[a-z0-9-]{1,64}$/).refine(id=>!id.startsWith('demo-')),name:z.string().min(1).max(80),mode:z.string().refine(x=>!!modeBySlug(x)),region:z.enum(['GE','DE','TR']),city:z.string().min(1).max(40),address:z.string().regex(/^(?:[a-zA-Z0-9](?:[a-zA-Z0-9.-]{0,251}[a-zA-Z0-9])?):[0-9]{1,5}$/).refine(a=>{const p=Number(a.split(':').pop());return p>0&&p<=65535}),capacity:z.number().int().min(2).max(128)});
export function configuredServers(){ const raw=process.env.CS2_SERVERS_JSON; if(!raw?.trim()) return null; return z.array(serverSchema).max(200).parse(JSON.parse(raw)); }
export function supabaseAdmin(){const url=process.env.NEXT_PUBLIC_SUPABASE_URL,key=process.env.SUPABASE_SERVICE_ROLE_KEY;if(!url||!key)throw new Error('Supabase server credentials are not configured');return createClient(url,key,{auth:{persistSession:false,autoRefreshToken:false}});}
export function supabasePublic(){const url=process.env.NEXT_PUBLIC_SUPABASE_URL,key=process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY;if(!url||!key)throw new Error('Supabase is not configured');return createClient(url,key,{auth:{persistSession:false,autoRefreshToken:false}});}
export function userClient(token:string){const url=process.env.NEXT_PUBLIC_SUPABASE_URL,key=process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY;if(!url||!key)throw new Error('Supabase is not configured');return createClient(url,key,{global:{headers:{Authorization:`Bearer ${token}`}},auth:{persistSession:false,autoRefreshToken:false}});}
export function bearer(request:Request){const value=request.headers.get('authorization');return value?.startsWith('Bearer ')?value.slice(7):null;}
export async function getServers():Promise<{servers:GameServer[];demo:boolean}>{
 const configured=configuredServers(); if(!configured)return {servers:[],demo:false};
 try{const {data,error}=await supabaseAdmin().from('server_snapshots').select('*');if(error)throw error;const rows=data??[];const servers:GameServer[]=configured.map(s=>{const snap=rows.find(r=>r.server_id===s.id);const fresh=!!snap&&Date.now()-Date.parse(snap.updated_at)<120000;return {...s,map:snap?.map??'—',players:fresh?snap.players:0,capacity:snap?.capacity??s.capacity,ping:null,online:fresh&&!!snap.online,demo:false,updatedAt:snap?.updated_at??null};});return {servers,demo:false};}catch{return {servers:configured.map(s=>({...s,map:'—',players:0,ping:null,online:false,demo:false,updatedAt:null})),demo:false};}
}
export function jsonError(message:string,status=400){return Response.json({error:message},{status,headers:{'Cache-Control':'no-store'}});}
export function safeOrigin(request:Request){const origin=request.headers.get('origin');return !!origin&&origin===new URL(request.url).origin;}
