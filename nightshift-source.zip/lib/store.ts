export const products = [
  { id: 'vip-basic', name: 'VIP Basic', rank: '01', tagline: 'შენი პირველი VIP სტატუსი', tier: 'basic' },
  { id: 'vip-major', name: 'VIP Major', rank: '02', tagline: 'შემდეგი საფეხური', tier: 'major' },
  { id: 'vip-grand', name: 'VIP Grand', rank: '03', tagline: 'გამორჩეული ადგილი გუნდში', tier: 'grand' },
  { id: 'vip-elite', name: 'VIP ELITE', rank: '04', tagline: 'უმაღლესი VIP სტატუსი', tier: 'elite' },
  { id: 'admin', name: 'Admin', rank: 'A', tagline: 'საზოგადოების ადმინისტრატორი', tier: null },
] as const;
export type StoreProduct = typeof products[number];
export const adminPlans = [
  { id: 'admin-month', label: '1 თვე', months: 1, cents: 1000 },
  { id: 'admin-quarter', label: '3 თვე', months: 3, cents: 1500 },
  { id: 'admin-lifetime', label: 'სამუდამო', months: 0, cents: 2500 },
] as const;
export function findPlan(id: string) { return adminPlans.find(plan => plan.id === id); }
