'use client';
import {createClient} from '@supabase/supabase-js';
let client:ReturnType<typeof createClient>|null=null;
export function browserSupabase(){if(!client){const url=process.env.NEXT_PUBLIC_SUPABASE_URL,key=process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY;if(!url||!key)throw new Error('Supabase ჯერ არ არის კონფიგურირებული.');client=createClient(url,key);}return client;}
