import test from 'node:test';
import assert from 'node:assert/strict';
import {createHmac} from 'node:crypto';
import {resolveMembership,mergeMemberships} from '../lib/membership.ts';
import {verifyStripeSignature,membershipExpiry} from '../lib/stripe.ts';
const now=Date.parse('2026-10-03T12:00:00Z');
test('default player and validated VIP tiers',()=>{
 assert.equal(resolveMembership({}).role,'player');
 assert.equal(resolveMembership({role:'vip'}).role,'vip');
 assert.equal(resolveMembership({vip_tier:'elite'}).vipTier,'elite');
 assert.equal(resolveMembership({vip_tier:'owner'}).role,'player');
});
test('expired and malformed memberships do not grant roles',()=>{
 for(const expiry of ['2020-01-01','invalid']) assert.equal(resolveMembership({role:'admin',membership_expires_at:expiry},undefined,'',now).role,'player');
 assert.equal(resolveMembership({},'owner@example.test',' OWNER@example.test ').role,'admin');
});
test('purchased roles are active, not revoked, and ordered by privilege',()=>{
 const base=resolveMembership({});
 const purchases=[{role:'vip',vip_tier:'elite',expires_at:null,revoked:false},{role:'admin',vip_tier:null,expires_at:'2026-11-01',revoked:false}];
 assert.equal(mergeMemberships(base,purchases,now).role,'admin');
 purchases[1].revoked=true;
 assert.equal(mergeMemberships(base,purchases,now).vipTier,'elite');
 purchases[0].expires_at='2020-01-01';
 assert.equal(mergeMemberships(base,purchases,now).role,'player');
});
test('Stripe verifies the exact raw payload, signature and recent timestamp',()=>{
 const body='{"id":"evt_test"}',secret='whsec_unit_test',timestamp=String(now/1000);
 const digest=createHmac('sha256',secret).update(`${timestamp}.${body}`).digest('hex');
 const signature=`t=${timestamp},v1=${digest}`;
 assert.equal(verifyStripeSignature(body,signature,secret,now),true);
 assert.equal(verifyStripeSignature(body+' ',signature,secret,now),false);
 assert.equal(verifyStripeSignature(body,signature,'wrong',now),false);
 assert.equal(verifyStripeSignature(body,signature,secret,now+301000),false);
 assert.equal(verifyStripeSignature(body,'t=bad,v1=aa',secret,now),false);
});
test('calendar-month duration clamps month-end; lifetime does not expire',()=>{
 const jan31=Date.parse('2026-01-31T12:00:00Z')/1000;
 assert.equal(membershipExpiry(jan31,1),'2026-02-28T12:00:00.000Z');
 assert.equal(membershipExpiry(jan31,3),'2026-04-30T12:00:00.000Z');
 assert.equal(membershipExpiry(jan31,0),null);
});
