CREATE TABLE `favorites` (
	`user_id` text NOT NULL,
	`server_id` text NOT NULL,
	PRIMARY KEY(`user_id`, `server_id`)
);
--> statement-breakpoint
CREATE TABLE `player_stats` (
	`id` text PRIMARY KEY NOT NULL,
	`name` text NOT NULL,
	`region` text NOT NULL,
	`rating` integer NOT NULL,
	`kills` integer NOT NULL,
	`deaths` integer NOT NULL,
	`wins` integer NOT NULL,
	`matches` integer NOT NULL,
	`headshots` integer NOT NULL,
	`mode` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `profiles` (
	`user_id` text PRIMARY KEY NOT NULL,
	`nickname` text NOT NULL,
	`region` text DEFAULT 'GE' NOT NULL,
	`bio` text DEFAULT '' NOT NULL,
	`created_at` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `server_snapshots` (
	`server_id` text PRIMARY KEY NOT NULL,
	`map` text NOT NULL,
	`players` integer NOT NULL,
	`capacity` integer NOT NULL,
	`online` integer NOT NULL,
	`updated_at` text NOT NULL
);
