create table if not exists public.cs2_servers (
  id text primary key check (id ~ '^[a-z0-9-]{1,64}$' and id not like 'demo-%'),
  name text not null check (char_length(name) between 2 and 80),
  mode text not null,
  region text not null check (region in ('GE','DE','TR')),
  city text not null check (char_length(city) between 1 and 40),
  address text not null check (char_length(address) between 3 and 255),
  capacity integer not null check (capacity between 2 and 128),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
alter table public.cs2_servers enable row level security;
drop policy if exists "Public can view configured servers" on public.cs2_servers;
create policy "Public can view configured servers" on public.cs2_servers for select using (true);

grant select on public.cs2_servers to anon, authenticated;
