create table if not exists public.profiles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  nickname text not null check (char_length(nickname) between 2 and 24),
  region text not null default 'GE' check (region in ('GE','DE','TR')),
  bio text not null default '' check (char_length(bio) <= 160),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.favorites (
  user_id uuid not null references auth.users(id) on delete cascade,
  server_id text not null check (char_length(server_id) between 1 and 64),
  created_at timestamptz not null default now(),
  primary key (user_id, server_id)
);

create table if not exists public.server_snapshots (
  server_id text primary key,
  map text not null,
  players integer not null check (players >= 0),
  capacity integer not null check (capacity between 2 and 128),
  online boolean not null default false,
  updated_at timestamptz not null default now(),
  check (players <= capacity)
);

create table if not exists public.player_stats (
  id text primary key,
  name text not null,
  region text not null check (region in ('GE','DE','TR')),
  rating integer not null default 0 check (rating >= 0),
  kills integer not null default 0 check (kills >= 0),
  deaths integer not null default 0 check (deaths >= 0),
  wins integer not null default 0 check (wins >= 0),
  matches integer not null default 0 check (matches >= wins),
  headshots integer not null default 0 check (headshots between 0 and 100),
  mode text not null
);

create index if not exists player_stats_rating_idx on public.player_stats (rating desc);
create index if not exists favorites_server_id_idx on public.favorites (server_id);

alter table public.profiles enable row level security;
alter table public.favorites enable row level security;
alter table public.server_snapshots enable row level security;
alter table public.player_stats enable row level security;

create policy "Profiles are private to their owner" on public.profiles
  for select to authenticated using ((select auth.uid()) = user_id);
create policy "Profiles can be created by their owner" on public.profiles
  for insert to authenticated with check ((select auth.uid()) = user_id);
create policy "Profiles can be updated by their owner" on public.profiles
  for update to authenticated using ((select auth.uid()) = user_id) with check ((select auth.uid()) = user_id);

create policy "Favorites are private to their owner" on public.favorites
  for select to authenticated using ((select auth.uid()) = user_id);
create policy "Favorites can be created by their owner" on public.favorites
  for insert to authenticated with check ((select auth.uid()) = user_id);
create policy "Favorites can be deleted by their owner" on public.favorites
  for delete to authenticated using ((select auth.uid()) = user_id);

create policy "Server snapshots are publicly readable" on public.server_snapshots
  for select to anon, authenticated using (true);
create policy "Player stats are publicly readable" on public.player_stats
  for select to anon, authenticated using (true);

revoke all on public.profiles, public.favorites, public.server_snapshots, public.player_stats from anon;
grant select, insert, update on public.profiles to authenticated;
grant select, insert, delete on public.favorites to authenticated;
grant select on public.server_snapshots, public.player_stats to anon, authenticated;
