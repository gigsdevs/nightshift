import { Crown, ShieldCheck, UserRound } from 'lucide-react';
import { vipNames, type Membership } from '@/lib/membership';
import { t } from '@/lib/i18n';

export function RoleBadge({ membership }: { membership?: Membership }) {
  const role = membership?.role || 'player';
  const Icon = role === 'admin' ? ShieldCheck : role === 'vip' ? Crown : UserRound;
  return <span className={`role-badge role-${role}`}><Icon size={14} />{role === 'admin' ? t('ადმინი') : role === 'vip' ? membership?.vipTier ? vipNames[membership.vipTier] : 'VIP' : t('მოთამაშე')}</span>;
}
