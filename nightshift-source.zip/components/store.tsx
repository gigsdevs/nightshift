'use client';
import { useEffect, useState, useSyncExternalStore } from 'react';
import Link from 'next/link';
import { ArrowUpRight, Check, Crown, ShieldCheck, Sparkles } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { products, adminPlans, type StoreProduct } from '@/lib/store';
import { browserSupabase } from '@/lib/supabase-browser';
import { t } from '@/lib/i18n';
const subscribeLocation = (callback: () => void) => { window.addEventListener('popstate', callback); return () => window.removeEventListener('popstate', callback); };
const locationStatus = () => new URLSearchParams(window.location.search).get('payment') || '';

export default function Store() {
  const [category, setCategory] = useState('all');
  const [selected, setSelected] = useState<StoreProduct | null>(null);
  const [planId, setPlanId] = useState<string>(adminPlans[0].id);
  const [method, setMethod] = useState('card');
  const [cardEnabled, setCardEnabled] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const status = useSyncExternalStore(subscribeLocation, locationStatus, () => '');
  const paymentStatus = status === 'processing' ? 'გადახდა მოწმდება. დადასტურების შემდეგ სტატუსი შენს პროფილზე გამოჩნდება.' : status === 'cancelled' ? 'გადახდა გაუქმებულია. შეგიძლია თავიდან სცადო.' : '';
  const plan = adminPlans.find(p => p.id === planId)!;
  useEffect(() => {
    fetch('/api/store').then(r => r.ok ? r.json() : null).then(data => setCardEnabled(!!data?.cardEnabled)).catch(() => {});
  }, []);
  async function checkout() {
    setBusy(true); setError('');
    try {
      const token = (await browserSupabase().auth.getSession()).data.session?.access_token;
      if (!token) { setError('საჭიროა ანგარიშში შესვლა.'); return; }
      const response = await fetch('/api/checkout', { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` }, body: JSON.stringify({ planId }) });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error);
      const url = new URL(data.url);
      if (url.protocol !== 'https:' || url.hostname !== 'checkout.stripe.com') throw new Error('გადახდის დაწყება ვერ მოხერხდა.');
      window.location.assign(url.href);
    } catch (e) { setError(e instanceof Error ? e.message : 'გადახდის დაწყება ვერ მოხერხდა.'); }
    finally { setBusy(false); }
  }
  const visible = products.filter(p => category === 'all' || (category === 'vip' ? p.tier : !p.tier));
  return <div className="store-page">
    {paymentStatus && <p role="status" className="payment-status">{t(paymentStatus)} <Link href="/profile">{t('ჩემი პროფილი')} ↗</Link></p>}
    <section className="store-hero"><div><span className="eyebrow"><Sparkles size={15} /> NIGHTSHIFT STORE</span><h1>{t('შენი თამაში.')}<br /><em>{t('შენი სტატუსი.')}</em></h1><p>{t('აირჩიე შენი VIP დონე და გახდი საზოგადოების გამორჩეული წევრი.')}</p></div><div className="store-emblem" aria-hidden="true"><Crown /><span>LEVEL UP</span></div></section>
    <div className="store-toolbar"><div className="store-filters" role="group" aria-label={t('მაღაზიის კატეგორიები')}>{[['all','ყველა'],['vip','VIP პაკეტები'],['admin','ადმინი']].map(([value,label]) => <button key={value} aria-pressed={category === value} onClick={() => setCategory(value)}>{t(label)}</button>)}</div><span>{visible.length} {t('პაკეტი')}</span></div>
    <div className="store-grid">{visible.map(p => <article className={`product-card tier-${p.tier || 'admin'}`} key={p.id}><div className="product-top"><span className="product-icon">{p.tier ? <Crown /> : <ShieldCheck />}</span><span className="product-rank">{p.rank} / {p.tier ? 'VIP' : 'ADMIN'}</span></div><h2>{p.name}</h2><p>{t(p.tagline)}</p><div className="product-divider"/><ul><li><Check size={16}/>{t(p.tier ? 'VIP როლი პროფილზე' : 'ადმინის როლი პროფილზე')}</li><li><Check size={16}/>{t('გამორჩეული სტატუსის ბეჯი')}</li><li><Check size={16}/>{p.name} {t('წევრობა')}</li></ul><div className="product-price">{p.tier ? t('მალე') : '$10 / $15 / $25'}<small>{p.tier ? t('ფასი და ვადა გამოცხადდება') : t('1 თვე / 3 თვე / სამუდამო')}</small></div><button className={`btn ${p.tier === 'elite' ? 'primary' : 'secondary'}`} onClick={() => setSelected(p)}>{t('დეტალების ნახვა')}<ArrowUpRight size={16}/></button></article>)}</div>
    <section className="store-note"><ShieldCheck size={26}/><div><h2>{t('შენი სტატუსი — შენს პროფილზე')}</h2><p>{t('მოთამაშე, VIP და ადმინი ცალკეული როლებია. აქტიური წევრობის სტატუსი გამოჩნდება შენს პროფილზე.')}</p></div><Link className="text-link" href="/profile">{t('ჩემი პროფილი')}<ArrowUpRight size={16}/></Link></section>
    <Dialog open={!!selected} onOpenChange={open => { if (!open) { setSelected(null); setError(''); } }}><DialogContent className="ns-dialog"><DialogHeader><DialogTitle>{selected?.name}</DialogTitle><DialogDescription>{t(selected?.tier ? 'ფასი და ვადა გამოცხადდება' : 'აირჩიე ვადა და გადახდის მეთოდი')}</DialogDescription></DialogHeader>
      {selected?.id === 'admin' && <><div className="period-select" role="group" aria-label={t('წევრობის ვადა')}>{adminPlans.map(p => <button key={p.id} aria-pressed={planId === p.id} onClick={() => setPlanId(p.id)}>{t(p.label)} · ${p.cents / 100}</button>)}</div><div className="payment-options" role="group" aria-label={t('გადახდის მეთოდი')}><button aria-pressed={method === 'card'} onClick={() => setMethod('card')}>Stripe<small>{t('ბარათით გადახდა')}</small></button><button aria-pressed={method === 'crypto'} onClick={() => setMethod('crypto')}>{t('კრიპტო')}<small>{t('კრიპტოვალუტით გადახდა')}</small></button></div><div className="checkout-total"><span>{t(plan.label)}</span><strong>${plan.cents / 100} USD</strong></div><p className="subtle">{t('ერთჯერადი გადახდა. ავტომატური განახლების გარეშე.')}</p>{method === 'crypto' ? <p role="status" className="payment-status">{t('კრიპტოგადახდა ჯერ არ არის გააქტიურებული.')}</p> : !cardEnabled ? <p role="status" className="payment-status">{t('ბარათით გადახდა ჯერ არ არის გააქტიურებული.')}</p> : <button className="btn primary" disabled={busy} onClick={checkout}>{busy ? t('იტვირთება...') : `${t('გადახდა')} · $${plan.cents / 100}`}</button>}</>}
      {error && <p role="alert" className="error-text">{t(error)}</p>}
      <p className="subtle">{t('სათამაშო სერვერის პრივილეგიები გამოქვეყნდება თითოეული პაკეტის პირობებთან ერთად.')}</p><Link className="btn secondary" href="/profile">{t('ჩემი პროფილი')}</Link></DialogContent></Dialog>
  </div>;
}
